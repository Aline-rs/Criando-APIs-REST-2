host='localhost'
user='admin'
password='admin123'
db = 'aeroportos'
